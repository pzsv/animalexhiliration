﻿using System;
namespace AnimalExhiliration
{
	public class Animal
	{
        protected string? Name { get; set; }
        protected string? Type { get; set; }

        protected int Exhiliration { get; set; }

		protected bool Alive { get; set; }

		protected int g;
        protected int o;
        protected int b;

        public Animal() { Alive = true; }

		public int HowAreYou()
		{
			if (Exhiliration > 0)
				Console.WriteLine(Name + " " + Type + " feels " + Exhiliration + " today.");
			else
				Console.WriteLine(Name + " " + Type + " is dead.");

			return Exhiliration;
		}




		public void NewDay(char ownersMood)
		{

			if (Alive) {
                switch (ownersMood)
                {
                    case 'g':
                        Exhiliration += g;
                        break;
                    case 'o':
                        Exhiliration += o;
                        break;
                    case 'b':
                        Exhiliration += b;
                        break;
                }

                if (Exhiliration <= 0)
                {
                    Alive = false;
                    Exhiliration = 0;
                }
            }
            

        }
	}
}


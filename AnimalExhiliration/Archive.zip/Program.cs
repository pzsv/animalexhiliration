﻿namespace AnimalExhiliration;


/* Exh change
 * 
 *          Bad Ord Good
 * Fish      -5  -3   1
 * Birds     -3  -1   2
 * Dogs     -10   0   3
 * 
 * 
 * Care
 *          Bad Ord Good
 * Fish               x
 * Birds              x
 * Dogs          x    x
 * 
 * 
 */

public class Program
{

    public static void Main()
    {
        Initialiser ini = new();
        Cathy cathy = new();


        HobbyAnimals hobbyAnimals = ini.GetHobbyAnimals();

        List<char> moods = ini.GetMoods();

        for (int i = 0; i < moods.Count; i++) {
            hobbyAnimals.NewDay(moods[i]);
            hobbyAnimals.HowIsEveryOne();

        }

    }


    public void test1() {

        Cathy cathy = new();
        Fish Nemo = new("Nemo", 50);

        //Nemo.HowAreYou();

        Fish Sharky = new("Sharky", 70);
        Dog Frakk = new("Frakk", 80);
        Bird Tweety = new("Tweety", 30);
        Bird Owl = new("Owl", 2);
        Fish Dory = new("Dory", 3);


        HobbyAnimals hobbyAnimals = new();

        hobbyAnimals.AddAnimal(Nemo);
        hobbyAnimals.AddAnimal(Sharky);
        hobbyAnimals.AddAnimal(Frakk);
        hobbyAnimals.AddAnimal(Tweety);
        hobbyAnimals.AddAnimal(Owl);

        hobbyAnimals.AddAnimal(Dory);




        //zoo.AddAnimal(Garfield);
        //zoo.AddAnimal(Mazsi);


        for (int i = 0; i < 100; i++)
        {
            bool allAliveAt5 = true;

            foreach (int ex in hobbyAnimals.HowIsEveryOne())
            {
                Console.WriteLine(ex);
                if (ex != 0 && ex < 5)
                {
                    allAliveAt5 = false;
                    break;
                }

            }

            Console.WriteLine(allAliveAt5);
            //Console.WriteLine(cathy.improveMood());

            if (allAliveAt5) hobbyAnimals.NewDay(cathy.improveMood());
            else hobbyAnimals.NewDay(cathy.reduceMood());
        }

    }



}



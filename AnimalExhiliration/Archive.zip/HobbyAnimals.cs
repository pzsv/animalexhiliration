﻿using System;

namespace AnimalExhiliration
{
	public class HobbyAnimals
	{
        readonly List<Animal> animals;

		public HobbyAnimals()
		{
			animals = new();
		}

		public void AddAnimal(Animal animal)
		{
			animals.Add(animal);
		}

		public void NewDay(char mood)
		{
			foreach (Animal a in animals)
			{
				a.NewDay(mood);
			}
		}

		public List<int> HowIsEveryOne()
		{
			List<int> Exhilirations = new();

			foreach (Animal a in animals)
			{
				Exhilirations.Add(a.HowAreYou());
			}

			return Exhilirations;

		}
	}
}


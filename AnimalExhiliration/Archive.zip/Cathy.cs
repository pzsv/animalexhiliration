﻿using System;
namespace AnimalExhiliration
{
	public class Cathy
	{

		protected char Mood { get; set; }

		public Cathy()
		{
			Mood = 'g';
		}

		public char improveMood()
		{
			switch (Mood)
			{
				case 'b':
					Mood = 'o';
					break;

				case 'o':
					Mood = 'g';
					break;
			}
			return Mood;
		}

        public char reduceMood()
        {
            switch (Mood)
            {
                case 'g':
                    Mood = 'o';
                    break;

                case 'o':
                    Mood = 'b';
                    break;
            }
            return Mood;
        }
    }
}

